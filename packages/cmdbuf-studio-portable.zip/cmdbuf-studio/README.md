# CMDBUF Studio — native Tk / local Linux

On the Linux EDA workstation, load your site's tool/license environment, then:
    python3 -c "import tkinter; print(tkinter.TkVersion)"
    make doctor
    make smoke
    make gui

Requires Python >= 3.6, Tk >= 8.5, a Linux graphical session, GNU Make,
compatible C/C++ tools, and licensed VCS / Verdi with FSDB PLI and NPI.
No browser, Node.js, HTTP service, SSH connection, or pip packages are required.
Tk installation if missing: Debian/Ubuntu python3-tk; RHEL/CentOS python3-tkinter.

Optional site configuration:
    export EDA_TOOL_SETUP=/absolute/path/to/site_setup.sh
Normally no paths are entered: the Local tools page automatically detects the
project, launch directory, commands, installation roots, PLI/NPI, and display.
Special sites can opt in to machine-bound overrides in Advanced options.
Old VM profiles and overrides copied from a different device are ignored.
Settings are saved to ignored eda.local.json; DISPLAY inherits the current desktop.

Compile / simulate / open waves and coverage all use Make:
    make compile
    make regress SEEDS=1,2,42 JOBS=2 WAVES=1
    make wave REGRESSION=latest CASE=tc_random SEED=42
    make coverage REGRESSION=latest
    make wave-file FSDB=/absolute/path/to/input.fsdb

The GUI includes DUT import and instantiation, a main_phase-only SV editor,
per-case seed sweeps, a native waveform canvas, local Verdi coverage, and direct
NPI FSDB-to-Formal generation with one pattern per FSDB. FSDB viewing uses local
fsdb2vcd for the canvas; Formal extraction reads FSDB directly through NPI.
Generated Formal packages require the site's formal engine; generation is not a proof.

Windows: make.cmd gui opens the same native editor and existing VCD viewer.
EDA commands intentionally require Linux; there is no remote-execution fallback.

Current Chinese Word/PDF manual: documents/36_*. TC guide: documents/32_*.
FSDB semantics: documents/34_*. Guides 33/35 describe the previous web/SSH UI.
Verify the archive: python3 simulation/vcs/portable.py --verify
No EDA binaries, licenses, credentials, machine settings, or prior results are shipped.
