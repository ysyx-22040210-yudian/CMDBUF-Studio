# CMDBUF Studio portable edition

Linux with VCS/Verdi already configured in the shell:
    make doctor
    make smoke
    make gui

If your site requires an environment script:
    export EDA_TOOL_SETUP=/absolute/path/to/site_setup.sh
    make doctor

Windows (Python 3.6+ and OpenSSH client; no Windows Make or Node.js needed):
    .\make.cmd gui
Choose SSH mode in connection settings. Enter user@host (or SSH alias),
an independent absolute remote directory, and optional tool setup path.
Alternatively:
    .\make.cmd configure MODE=ssh HOST=user@eda ROOT=/home/user/cmdbuf_studio
    .\make.cmd doctor
    .\make.cmd smoke
Use an existing authenticated SSH connection (test with ssh user@eda).

GUI: DUT import, main_phase editor, per-case seed sweeps, FSDB/VCD viewers,
Verdi coverage, and direct NPI FSDB-to-Formal generation are included.
Native EDA execution requires Linux x86_64, licensed VCS/Verdi, GNU Make,
Python >=3.6, a compatible C/C++ toolchain and Verdi PLI/NPI components.
The GUI uses a modern browser; all web assets are bundled for offline use.
Verdi windows require a usable DISPLAY and desktop authorization.
SBY/Yosys/read_slang/ABC/Yices are optional, used only by generated bmc/cover jobs.

Machine settings: eda.local.json (created by GUI/configure, never distributed).
Site scripts should set the site's own license environment. No license, EDA
binary, cached simv, previous results, password, or machine configuration is bundled.
Run doctor to locate components; smoke compiles and runs real cases to check licensing.

Detailed Chinese Word/PDF guides: documents/32*, 33*, 34*, 35*.
Current source and protocol contracts are included; historical evidence is kept
in the original repository, separate from this clean runtime distribution.
Verify the archive with: python3 simulation/vcs/portable.py --verify
